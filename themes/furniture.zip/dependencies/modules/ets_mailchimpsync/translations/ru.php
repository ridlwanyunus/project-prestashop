<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_mailchimpsync}prestashop>ets_mailchimpsync_7344e7ab843aebf9b90367c42a776f55'] = 'Automatic Mailchimp Sync';
