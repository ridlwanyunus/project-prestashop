INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('73','_ID_LANG_','excellent service','','<p>We always listen to you</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('74','_ID_LANG_','24/7 suport','','<p>We’re online all the time</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('75','_ID_LANG_','Free return','','<p>Within 30 days after sale</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('76','_ID_LANG_','Free gift','','<p>All orders over $100</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('77','_ID_LANG_','New design','','<h4><span class=\"main-color\">New</span> Design</h4>
<p>Lorem ipsum dolor sit<br /> amet, consectetur ipsum<br /> elit. Integer</p>
<p><a href=\"https://preview.etssoft.net/themes/furniture/en/10-chairs\">Purchase Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('78','_ID_LANG_','new sofa','','<h4><span class=\"main-color\">New</span> Sofas</h4>
<p>Lorem ipsum dolor sit amet, consectetur ipsum elit. Integer</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('79','_ID_LANG_','The biggest sale ever','Save up to 50%','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit. Integer nec odio. Praesent <br /> libero. Sed cursus ante dapibus</p>
<p><a href=\"https://preview.etssoft.net/themes/furniture/en/11-lighting\">Purchase Now </a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('80','_ID_LANG_','Furniture design','20% OFF','<h4><span class=\"main_color\">Furniture</span> design</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. <br /> Sed cursus ante dapibus diam. Sed nisi. Nulla</p>
<p><a href=\"#\">Discover Now&gt;&gt;</a></p>');


