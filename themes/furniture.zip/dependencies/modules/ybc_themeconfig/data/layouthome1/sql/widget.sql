INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('73','ybcCustom1','1','1','1','1','','fa-coffee','','1','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('74','ybcCustom1','1','1','1','1','','fa-headphones','','3','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('75','ybcCustom1','1','1','1','1','','fa-refresh','','2','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('76','ybcCustom1','1','1','1','1','','fa-gift','','4','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('77','displayTopColumn','1','0','1','1','bn1.jpg','','https://preview.etssoft.net/themes/furniture/en/10-chairs','1','des_pos_left');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('78','displayTopColumn','1','0','1','1','bn2.jpg','','https://preview.etssoft.net/themes/furniture/en/8-sofa','2','des_pos_center_bottom');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('79','displayTopColumn','1','1','1','1','bn3.jpg','','https://preview.etssoft.net/themes/furniture/en/11-lighting','3','des_pos_right');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('80','displayHome','1','0','1','1','bnh.jpg','','#','1','');


